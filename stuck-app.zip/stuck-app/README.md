# Stuck
Email sign-in, 7-day free trial, then a one-time $4.99 unlock (PayPal on the web, in-app purchase in the stores).
Static app in `public/`, serverless API in `api/`, store wrapper in `store/`.

## Web setup (about 20 minutes)
1. **Vercel**: upload this folder (or `npx vercel`).
2. **Redis**: in the Vercel project add the free **Upstash Redis** integration.
3. **Anthropic**: add `ANTHROPIC_API_KEY`.
4. **Email codes**: create a free account at resend.com, verify a sending domain, add `RESEND_API_KEY`, `FROM_EMAIL`, and a random `AUTH_SECRET`.
5. **PayPal**: you need a PayPal *Business* account (free upgrade of a personal one). At developer.paypal.com create an app, copy the
   Client ID and Secret into `PAYPAL_CLIENT_ID` / `PAYPAL_CLIENT_SECRET`. Start with `PAYPAL_ENV=sandbox` and a sandbox buyer account,
   then switch to `live` with your live keys. Money lands in your PayPal balance.
6. Redeploy and test the full flow: sign in, ask, wait out (or edit) the trial, pay.

## How it works
- Sign in with an emailed 6-digit code. The first sign-in starts the 7-day trial for that email (one trial per email, even across devices).
- After 7 days the paywall appears. Paying through PayPal captures $4.99 on the server, checks the amount, and unlocks that email for good.
- Signing in on a new phone restores everything automatically. Sign out and Delete account are in the menu (tap the trial badge).
- Each account is capped at 60 answers/day to protect your API bill.

## Store apps
See `store/STORE.md`.

## Known limits
- Someone can start a new trial with a new email address.
- PayPal refunds are not wired to auto-lock an account; handle refunds manually for now.

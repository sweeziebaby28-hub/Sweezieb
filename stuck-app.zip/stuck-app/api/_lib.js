import crypto from "node:crypto";
export const DAY = 86400000, TRIAL_DAYS = 7;
export const h = s => crypto.createHash("sha256").update(String(s).toLowerCase()).digest("hex");

// Upstash Redis over REST. Works with either env var naming.
export async function redis(...cmd) {
  const url = process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
  const r = await fetch(url, { method: "POST", headers: { Authorization: "Bearer " + token }, body: JSON.stringify(cmd.map(String)) });
  const j = await r.json();
  if (j.error) throw new Error(j.error);
  return j.result;
}

// Lets the store apps (capacitor://localhost, https://localhost) call this API.
export function cors(req, res) {
  const o = req.headers.origin || "";
  if (/^(capacitor|ionic):\/\/localhost$|^https?:\/\/localhost(:\d+)?$/.test(o)) { res.setHeader("Access-Control-Allow-Origin", o); res.setHeader("Vary", "Origin"); }
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  if (req.method === "OPTIONS") { res.status(204).end(); return true; }
  return false;
}

export function tokenOf(req) {
  const t = (req.headers.authorization || "").replace(/^Bearer /, "");
  return /^[a-f0-9]{64}$/.test(t) ? t : null;
}
export async function userFrom(req) {
  const t = tokenOf(req);
  return t ? await redis("GET", "sess:" + t) : null;
}

// paid -> forever. Otherwise a 7-day trial that starts the first time this email signs in.
export async function getStatus(email) {
  const k = h(email);
  if (await redis("GET", "paid:" + k)) return { plan: "paid", daysLeft: 0 };
  await redis("SET", "trial:" + k, String(Date.now()), "NX");
  const start = Number(await redis("GET", "trial:" + k));
  const left = Math.ceil((start + TRIAL_DAYS * DAY - Date.now()) / DAY);
  return left > 0 ? { plan: "trial", daysLeft: Math.min(left, TRIAL_DAYS) } : { plan: "expired", daysLeft: 0 };
}

export const paypalBase = () => process.env.PAYPAL_ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
export async function paypalToken() {
  const auth = Buffer.from(process.env.PAYPAL_CLIENT_ID + ":" + process.env.PAYPAL_CLIENT_SECRET).toString("base64");
  const r = await fetch(paypalBase() + "/v1/oauth2/token", { method: "POST", headers: { Authorization: "Basic " + auth, "Content-Type": "application/x-www-form-urlencoded" }, body: "grant_type=client_credentials" });
  const j = await r.json();
  if (!j.access_token) throw new Error("paypal auth");
  return j.access_token;
}

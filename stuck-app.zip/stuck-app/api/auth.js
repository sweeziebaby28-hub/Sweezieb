import crypto from "node:crypto";
import { redis, cors, tokenOf, userFrom, h } from "./_lib.js";
// Passwordless email sign-in: POST /api/auth?a=start | verify | logout | delete
const hashCode = (email, code) => crypto.createHash("sha256").update(email + ":" + code + ":" + (process.env.AUTH_SECRET || "")).digest("hex");
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== "POST") return res.status(405).end();
  const a = req.query.a, b = req.body || {};
  try {
    if (a === "start") {
      const email = String(b.email || "").trim().toLowerCase();
      if (!EMAIL.test(email) || email.length > 120) return res.status(400).json({ error: "email" });
      const rk = "ar:" + h(email), n = await redis("INCR", rk);
      if (n === 1) await redis("EXPIRE", rk, 3600);
      if (n > 5) return res.status(429).json({ error: "slow" });
      const code = String(crypto.randomInt(0, 1000000)).padStart(6, "0");
      await redis("SET", "code:" + h(email), hashCode(email, code), "EX", 600);
      await redis("DEL", "tries:" + h(email));
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { Authorization: "Bearer " + process.env.RESEND_API_KEY, "Content-Type": "application/json" },
        body: JSON.stringify({ from: process.env.FROM_EMAIL, to: [email], subject: "Your Stuck code: " + code, text: "Your Stuck sign-in code is " + code + ". It expires in 10 minutes. If you didn't ask for it, ignore this email." }),
      });
      return r.ok ? res.status(200).json({ ok: true }) : res.status(502).json({ error: "email" });
    }
    if (a === "verify") {
      const email = String(b.email || "").trim().toLowerCase(), code = String(b.code || "").trim();
      const tk = "tries:" + h(email), t = await redis("INCR", tk);
      if (t === 1) await redis("EXPIRE", tk, 600);
      if (t > 5) return res.status(429).json({ error: "slow" });
      const stored = await redis("GET", "code:" + h(email));
      if (!stored || stored !== hashCode(email, code)) return res.status(400).json({ error: "code" });
      await redis("DEL", "code:" + h(email));
      const token = crypto.randomBytes(32).toString("hex");
      await redis("SET", "sess:" + token, email, "EX", 90 * 86400);
      return res.status(200).json({ token, email });
    }
    if (a === "logout" || a === "delete") {
      const email = await userFrom(req), tok = tokenOf(req);
      if (!email) return res.status(401).json({ error: "auth" });
      if (a === "delete") await redis("DEL", "paid:" + h(email), "code:" + h(email)); // trial marker is kept (hashed) so deleting can't reset a trial
      await redis("DEL", "sess:" + tok);
      return res.status(200).json({ ok: true });
    }
    return res.status(400).json({ error: "bad" });
  } catch (e) { return res.status(500).json({ error: "server" }); }
}

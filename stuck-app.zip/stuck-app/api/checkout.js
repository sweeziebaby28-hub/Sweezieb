import { redis, cors, userFrom, paypalBase, paypalToken } from "./_lib.js";
// Creates a one-time $4.99 PayPal order and returns the PayPal approval link.
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== "POST") return res.status(405).end();
  const email = await userFrom(req);
  if (!email) return res.status(401).json({ error: "auth" });
  const origin = (req.headers["x-forwarded-proto"] || "https") + "://" + req.headers.host;
  try {
    const tok = await paypalToken();
    const r = await fetch(paypalBase() + "/v2/checkout/orders", {
      method: "POST",
      headers: { Authorization: "Bearer " + tok, "Content-Type": "application/json" },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [{ description: "Stuck Plus (one-time)", amount: { currency_code: "USD", value: "4.99" } }],
        payment_source: { paypal: { experience_context: { brand_name: "Stuck", user_action: "PAY_NOW", shipping_preference: "NO_SHIPPING", return_url: origin + "/api/paypal-return", cancel_url: origin + "/" } } },
      }),
    });
    const j = await r.json();
    const link = (j.links || []).find(l => l.rel === "payer-action" || l.rel === "approve");
    if (!link) return res.status(502).json({ error: "paypal" });
    await redis("SET", "order:" + j.id, email, "EX", 7200); // remember who this order belongs to
    return res.status(200).json({ url: link.href });
  } catch (e) { return res.status(502).json({ error: "paypal" }); }
}

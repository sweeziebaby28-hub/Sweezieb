import { getStatus, redis, h, cors, userFrom } from "./_lib.js";
// Serverless function (Vercel). Keeps your Anthropic API key off the phone.
const VOICES = {
  Warm: "warm, kind and reassuring",
  Blunt: "blunt and no-nonsense, a little sharp but never cruel",
  Funny: "witty and playful, with a light joke",
};

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== "POST") return res.status(405).end();
  const { q, tone, when } = req.body || {};
  if (typeof q !== "string" || !q.trim() || q.length > 200) return res.status(400).json({ error: "bad question" });
  try {
    const email = await userFrom(req);
    if (!email) return res.status(401).json({ error: "sign in" });
    const st = await getStatus(email);
    if (st.plan === "expired") return res.status(402).json({ error: "payment required" });
    const key = "rl:" + h(email) + ":" + new Date().toISOString().slice(0, 10);
    const n = await redis("INCR", key);
    if (n === 1) await redis("EXPIRE", key, 90000);
    if (n > 60) return res.status(429).json({ error: "slow down" });
  } catch (e) { return res.status(503).json({ error: "unavailable" }); }
  const voice = VOICES[tone] || VOICES.Warm;
  const prompt =
    "You are Stuck, a decisive friend who settles small everyday decisions for indecisive people. " +
    "Pick exactly one answer, yes or no. Never hedge or say it depends. Base the reason on the specifics of the question and common sense (health, money, time, mood, what they will likely regret). " +
    "Current time: " + String(when || "").slice(0, 60) + ". Voice: " + voice + ". " +
    "Be well informed: draw on real evidence and practical knowledge and use concrete facts or numbers only when they genuinely help; never invent statistics. " +
    "The reason is 1 to 2 sentences spoken directly to the person. Factors are 2 to 3 short, specific points (each under 22 words) that actually tipped the decision. " +
    "The tip is one practical next step, or a smart alternative if the answer is no. Set close to true only if it was genuinely a near toss-up. " +
    "If the question is not a small everyday decision or is unsafe (medical emergencies, self-harm, major life or legal decisions), answer no and gently suggest talking to a real person. " +
    'Reply with only JSON: {"answer":"yes" or "no","reason":"...","factors":["...","..."],"tip":"...","close":false}\n\nQuestion: ' + q.trim();
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 600, messages: [{ role: "user", content: prompt }] }),
    });
    const data = await r.json();
    const text = (data.content || []).map(c => c.text || "").join("");
    const m = text.match(/\{[\s\S]*\}/);
    return res.status(200).json(JSON.parse(m[0]));
  } catch (e) {
    return res.status(502).json({ error: "upstream" });
  }
}

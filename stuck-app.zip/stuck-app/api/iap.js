import { redis, cors, userFrom, h } from "./_lib.js";
// Store apps: after an Apple/Google purchase, RevenueCat knows about it. We ask RevenueCat (server to server) and unlock.
export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== "POST") return res.status(405).end();
  const email = await userFrom(req);
  if (!email) return res.status(401).json({ error: "auth" });
  try {
    const r = await fetch("https://api.revenuecat.com/v1/subscribers/" + h(email), { headers: { Authorization: "Bearer " + process.env.REVENUECAT_SECRET_KEY } });
    const j = await r.json();
    const e = j.subscriber && j.subscriber.entitlements && j.subscriber.entitlements.plus;
    if (e && (!e.expires_date || new Date(e.expires_date) > new Date())) {
      await redis("SET", "paid:" + h(email), "1");
      return res.status(200).json({ ok: true });
    }
    return res.status(200).json({ ok: false });
  } catch (err) { return res.status(502).json({ ok: false }); }
}

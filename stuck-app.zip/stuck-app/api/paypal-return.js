import { redis, h, paypalBase, paypalToken } from "./_lib.js";
// PayPal sends the buyer back here after approval. We capture the money, verify it, then unlock.
const go = (res, to) => { res.setHeader("Location", to); res.status(302).end(); };
export default async function handler(req, res) {
  const id = String(req.query.token || "");
  if (!/^[A-Z0-9]{8,30}$/.test(id)) return go(res, "/?paid=0");
  try {
    const email = await redis("GET", "order:" + id);
    if (!email) return go(res, "/?paid=0");
    if (await redis("GET", "paid:" + h(email))) return go(res, "/?paid=1");
    const tok = await paypalToken();
    const r = await fetch(paypalBase() + "/v2/checkout/orders/" + id + "/capture", { method: "POST", headers: { Authorization: "Bearer " + tok, "Content-Type": "application/json" }, body: "{}" });
    const j = await r.json();
    const cap = j.purchase_units && j.purchase_units[0] && j.purchase_units[0].payments && j.purchase_units[0].payments.captures && j.purchase_units[0].payments.captures[0];
    if (j.status === "COMPLETED" && cap && cap.status === "COMPLETED" && cap.amount.value === "4.99" && cap.amount.currency_code === "USD") {
      await redis("SET", "paid:" + h(email), "1");
      await redis("DEL", "order:" + id);
      return go(res, "/?paid=1");
    }
  } catch (e) {}
  return go(res, "/?paid=0");
}

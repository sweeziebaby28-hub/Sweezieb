import { getStatus, cors, userFrom, h } from "./_lib.js";
export default async function handler(req, res) {
  if (cors(req, res)) return;
  try {
    const email = await userFrom(req);
    if (!email) return res.status(401).json({ error: "auth" });
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).json({ ...(await getStatus(email)), email, uid: h(email) });
  } catch (e) { return res.status(500).json({ error: "status" }); }
}

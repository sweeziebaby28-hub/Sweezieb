// Web build: same-origin API. The store build replaces this file (see store/config.store.js).
window.STUCK_API = "";

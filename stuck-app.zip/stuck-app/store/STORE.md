# Putting Stuck in the App Store and Google Play

Payments in the store apps use Apple / Google in-app purchase (required by both stores), handled through RevenueCat.
The same account (email) is unlocked whether the person paid by PayPal on the web or by in-app purchase on a phone.

## One-time setup
1. Deploy the backend (see ../README.md) and add `REVENUECAT_SECRET_KEY` to your Vercel environment variables.
2. Developer accounts: Apple Developer ($99/yr, needs a Mac with Xcode) and Google Play Console ($25 once, needs Android Studio).
3. Create the product in both stores: a one-time (non-consumable) purchase, id `stuck_plus`, price tier $4.99.
4. RevenueCat (free to start): add your iOS and Android apps, add the product, create an entitlement with the exact id `plus`,
   attach the product to the default offering. Copy the two public SDK keys into `config.store.js`, and set your backend URL.
5. Edit `capacitor.config.json` and set your own `appId` (for example `com.yourname.stuck`).

## Build the apps
```
cd store
npm install
npm run build
npx cap add ios && npx cap add android     # first time only
npx cap open ios        # Xcode: set signing team, then Product > Archive > Distribute
npx cap open android    # Android Studio: Build > Generate Signed Bundle (AAB), upload to Play Console
```
Re-run `npm run build` after any change to `../public`.

## Before you submit
- Privacy policy: edit `public/privacy.html`, redeploy, and give its URL to both stores.
- Microphone: iOS needs `NSMicrophoneUsageDescription` and `NSSpeechRecognitionUsageDescription` in Info.plist; Android needs the RECORD_AUDIO permission.
  Heads up: the browser speech-to-text used on the web does not run inside the iOS/Android web views, so the mic button hides itself in the store apps
  until you add a native speech plugin (for example @capacitor-community/speech-recognition). Typing and "Listen" (read aloud) work.
- Account deletion is built in (required by Apple). Sign-in is email code, so Sign in with Apple is not required.
- Apple can reject apps that are only a website in a shell. Stuck has accounts, in-app purchase and AI features, which helps, but there is no guarantee.
- Apple and Google keep 15-30% of each sale (15% if you qualify for their small-business programs).

#!/bin/bash
set -e
cd "$(dirname "$0")"
rm -rf www && cp -R ../public www
cp config.store.js www/config.js
rm -f www/sw.js
sed -i.bak '/serviceWorker/d' www/index.html && rm -f www/index.html.bak
npx cap sync

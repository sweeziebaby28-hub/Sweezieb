// Used only inside the store apps. Fill these in.
window.STUCK_API = "https://YOUR-SITE.vercel.app";   // your deployed backend
window.STUCK_RC_IOS = "appl_XXXXXXXX";               // RevenueCat public iOS SDK key
window.STUCK_RC_ANDROID = "goog_XXXXXXXX";           // RevenueCat public Android SDK key
